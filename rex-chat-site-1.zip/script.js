const input = document.getElementById("mensagemInput");
const mensagensDiv = document.getElementById("mensagens");
const form = document.getElementById("formMensagem");
const limparBtn = document.getElementById("limparBtn");

let mensagens = carregarMensagens();

function carregarMensagens() {
  try {
    const dados = JSON.parse(localStorage.getItem("rexChat"));
    return Array.isArray(dados) ? dados : [];
  } catch {
    return [];
  }
}

function salvar() {
  localStorage.setItem("rexChat", JSON.stringify(mensagens));
}

function horarioAtual() {
  return new Date().toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit"
  });
}

function escapar(texto) {
  return String(texto)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function mostrarMensagens() {
  mensagensDiv.innerHTML = "";

  mensagens.forEach((msg, index) => {
    const div = document.createElement("div");
    div.className = `mensagem ${msg.eu ? "minha" : "outra"}`;

    div.innerHTML = `
      <div class="nome">${escapar(msg.nome)}</div>
      <div class="texto">${escapar(msg.texto)}</div>
      <div class="hora">${escapar(msg.hora)}</div>
      <div class="acoes">
        ${msg.eu ? `<button type="button" data-action="editar" data-index="${index}">✏️ Editar</button>` : ""}
        <button type="button" data-action="apagar" data-index="${index}">🗑️ Apagar</button>
      </div>
    `;

    mensagensDiv.appendChild(div);
  });

  mensagensDiv.scrollTop = mensagensDiv.scrollHeight;
}

function enviarMensagem() {
  const texto = input.value.trim();

  if (!texto) return;

  mensagens.push({
    nome: "Você",
    texto,
    hora: horarioAtual(),
    eu: true
  });

  salvar();
  mostrarMensagens();

  input.value = "";
  input.focus();
}

function apagarMensagem(index) {
  if (!Number.isInteger(index) || !mensagens[index]) return;

  if (confirm("Apagar esta mensagem?")) {
    mensagens.splice(index, 1);
    salvar();
    mostrarMensagens();
  }
}

function editarMensagem(index) {
  if (!Number.isInteger(index) || !mensagens[index]) return;

  const novoTexto = prompt(
    "Edite sua mensagem:",
    mensagens[index].texto
  );

  if (novoTexto === null) return;

  const texto = novoTexto.trim();

  if (!texto) return;

  mensagens[index].texto = texto;
  mensagens[index].hora = horarioAtual();

  salvar();
  mostrarMensagens();
}

function limparChat() {
  if (mensagens.length === 0) return;

  if (confirm("Tem certeza que deseja apagar toda a conversa?")) {
    mensagens = [];
    salvar();
    mostrarMensagens();
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  enviarMensagem();
});

limparBtn.addEventListener("click", limparChat);

mensagensDiv.addEventListener("click", (event) => {
  const botao = event.target.closest("button[data-action]");
  if (!botao) return;

  const index = Number(botao.dataset.index);
  const action = botao.dataset.action;

  if (action === "editar") editarMensagem(index);
  if (action === "apagar") apagarMensagem(index);
});

mostrarMensagens();
input.focus();
